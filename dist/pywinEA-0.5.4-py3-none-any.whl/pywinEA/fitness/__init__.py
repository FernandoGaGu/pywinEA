from .objective import MonoObjectiveCV

__all__ = ['MonoObjectiveCV']
