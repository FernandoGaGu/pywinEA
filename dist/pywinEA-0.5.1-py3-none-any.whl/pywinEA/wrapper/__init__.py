from .wrapper import Parallel
from .wrapper import IslandModel

__all__ = ['Parallel', 'IslandModel']